shopping_list = []

while True:
    print("\n1. Add item")
    print("2. Remove item")
    print("3. Show sorted list")
    print("4. Exit")

    x = int(input("Enter your choice (1-4): "))

    if x == 1:
        item = input("Enter item to add: ")

        shopping_list.append(item)
        print(f"{item} added.")

    elif x == 2:
        item = input("Enter item to remove: ")

        if item in shopping_list :
            shopping_list.remove(item)
            print(f"{item} removed.")
        else :
            print(f"{item} not found.")

    elif x == 3 :
        shopping_list.sort()
        print(f"Shopping list: {shopping_list}")

    elif x == 4 :
        print("Goodbye!")
        break

    else:
        print("Invalid choice.")
