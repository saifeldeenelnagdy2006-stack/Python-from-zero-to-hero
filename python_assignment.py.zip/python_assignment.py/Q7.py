def removeAllOccurrences(lst, value) :
    while value in lst :
        lst.remove(value)
    return lst

"""
num = [50, 10, 20, 30, 40, 50, 50, 60, 70, 50, 80]
result = removeAllOccurrences(num, 50)
print(result)
"""