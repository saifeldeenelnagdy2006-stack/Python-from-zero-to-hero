def modifyList(lst) :
    lst.append(100)

    lst.insert(2, 999)

    if lst.count(50) > 0 : # = if 50 in lst : lst.remove(50)
        lst.remove(50)
    
    lst.pop()
    return lst

"""
num = [10, 20, 30, 40, 50]
result = modifyList(num)
print(result)
"""