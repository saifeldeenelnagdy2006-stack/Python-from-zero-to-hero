student = []

for i in range(5) :
    name = input("Enter student name : ")
    grade = float(input("Enter student grade : "))
    student.append([name, grade])

high = student[0]
low = student[0]

for j in student :
    if j[1] > high[1] :
        high = j
    if j[1] < low[1] :
        low = j

print(f"Student with higest grade : {high[0]} - {high[1]}")
print(f"Student with lowest grade : {low[0]} - {low[1]}")