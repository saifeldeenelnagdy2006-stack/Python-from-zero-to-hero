def modifyFruits(fruits) :
    fruits.append("Kiwi")
    fruits.insert(2, "grape")
    fruits[0] = fruits[0].upper()
    fruits.pop(1)
    return fruits

"""
fruitList = ["Banana", "Mango", "Orange"]
print(modifyFruits(fruitList))
"""