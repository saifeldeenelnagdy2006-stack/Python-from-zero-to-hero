cityList = []

for i in range(7) :
    x = input(f"Enter city name ( {i+1} ): ")
    cityList.append(x)

for x in cityList :
    print(f"{x} is {len(x)} letters!")