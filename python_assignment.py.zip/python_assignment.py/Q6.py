temperatures = []
for i in range(10) :
    x = float(input("Enter Temperatures : "))
    temperatures.append(x)

above = 0
below = 0

for x in temperatures :
    if x > 30 :
        above += 1
    else :
        below += 1

print()
print(f"The list of Temperatures is : {temperatures}")

print()
print(f"The temperatures above 30 : {above}")

print()
print(f"The temperatures above 15 : {below}")