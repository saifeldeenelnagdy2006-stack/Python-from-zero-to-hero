listNumber = []

while True :
    x = input(f"Enter a number for list if you want finish to Write a number write 'done' : ")
    if x == "done" :
        break
    listNumber.append(float(x))

print()
print(f"Original list {listNumber}")

print()
listNumber.sort()
print(f"Ascending list is {listNumber}")

print()
listNumber.sort(reverse = True)
print(f"Descending list is {listNumber}")

print()