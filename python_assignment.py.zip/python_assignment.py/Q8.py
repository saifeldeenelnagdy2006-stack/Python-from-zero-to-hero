secretNumber = 42
attem = 0

while True :
    x = int(input("Guess the number : "))
    attem += 1

    if x > secretNumber : print("Too high")

    elif x < secretNumber : print("Too low")

    else :
        print("Correct!")
        print(f"Number of attempts is : {attem}")
        break