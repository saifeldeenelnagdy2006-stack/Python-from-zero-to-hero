name = input("Enter your name : ")
age = int(input("Enter your age : "))

person = [name, age]

if person[1] < 18 :
    print(f"{person[0]} have {person[1]} year , is Young")
elif 18 <= person[1] <= 60 :
    print(f"{person[0]} have {person[1]} year , is Adult")
else :
    print(f"{person[0]} have {person[1]} year , is Senior")